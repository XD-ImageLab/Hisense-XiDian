import streamlit as st

st.set_page_config(page_title="路口与摄像头管理", layout="wide")

st.title("🚦 路口与区域管理系统")

st.markdown("""
- 请通过左侧菜单访问：
- 摄像头管理 
- 路口管理
- 区域管理
- 区域-摄像头绑定
- 节点管理
""")
